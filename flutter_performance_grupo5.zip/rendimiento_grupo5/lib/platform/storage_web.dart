import 'dart:js_interop';
import 'package:web/web.dart' as web;

const _stateKey = 'grupo5_state_v1';

Future<String?> loadState() async => web.window.localStorage.getItem(_stateKey);

Future<void> saveState(String data) async {
  web.window.localStorage.setItem(_stateKey, data);
}

Future<void> writeRaw(String id, String data) async {}
Future<String> readRaw() async => '';

Future<bool> saveFile(String name, String data) async {
  final blob = web.Blob(
    <JSAny>[data.toJS].toJS,
    web.BlobPropertyBag(type: 'text/csv;charset=utf-8'),
  );
  final url = web.URL.createObjectURL(blob);
  final anchor = web.document.createElement('a') as web.HTMLAnchorElement;
  anchor.href = url;
  anchor.download = name;
  anchor.style.display = 'none';
  try {
    web.document.body?.appendChild(anchor);
    anchor.click();
    await Future<void>.delayed(const Duration(milliseconds: 500));
    return true;
  } finally {
    anchor.remove();
    web.URL.revokeObjectURL(url);
  }
}

void mark(String name) {
  web.window.performance.mark(name);
}
