import 'dart:developer' as dev;
import 'package:flutter/services.dart';
const _channel = MethodChannel('sv.edu.utec.rendimiento/export');
Future<String?> loadState() => _channel.invokeMethod<String>('loadState');
Future<void> saveState(String data) => _channel.invokeMethod<void>('saveState', data);
Future<void> writeRaw(String id, String data) => _channel.invokeMethod<void>('writeRaw', {'id':id, 'data':data});
Future<String> readRaw() async => await _channel.invokeMethod<String>('readRaw') ?? '';
Future<bool> saveFile(String name, String data) async => await _channel.invokeMethod<bool>('export', {'name':name,'data':data}) ?? false;
void mark(String name) => dev.Timeline.instantSync(name);
