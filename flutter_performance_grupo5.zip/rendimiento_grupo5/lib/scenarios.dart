import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'protocol.dart';

const palette = [Color(0xff56b7e9),Color(0xff43c9a6),Color(0xffffbc6c),Color(0xffa99af4),Color(0xfff282a6)];

Widget scenarioWidget(Trial trial, {bool? optimized}) {
  final opt = optimized ?? trial.variant.optimizes(trial.scenario);
  return switch (trial.scenario) {
    Scenario.transitions => TransitionScene(count:trial.elements, optimized:opt),
    Scenario.lists => ListScene(count:trial.elements, optimized:opt),
    Scenario.transforms => TransformScene(count:trial.elements, optimized:opt),
  };
}

class TransitionScene extends StatefulWidget {
  const TransitionScene({super.key, required this.count, required this.optimized});
  final int count;
  final bool optimized;
  @override State<TransitionScene> createState() => _TransitionSceneState();
}
class _TransitionSceneState extends State<TransitionScene> with SingleTickerProviderStateMixin {
  late final AnimationController _motion;
  @override void initState() {
    super.initState();
    _motion = AnimationController(vsync:this, duration:const Duration(seconds:2));
    if (!widget.optimized) _motion.addListener(_rebuild);
    _motion.repeat();
  }
  void _rebuild() { if (mounted) setState(() {}); }
  @override void dispose() { _motion.dispose(); super.dispose(); }
  Widget _pages(double t) {
    final scaled = t * 2;
    final from = scaled < 1 ? 0 : 1;
    final p = scaled - from;
    final progress = Curves.easeInOut.transform(p.clamp(0.0,1.0).toDouble());
    return LayoutBuilder(builder:(context, constraints) {
      final w = constraints.maxWidth;
      return ClipRect(child:Stack(fit:StackFit.expand, children:[
        Transform.translate(offset:Offset(-w * progress,0), child:_Panel(page:from, count:widget.count)),
        Transform.translate(offset:Offset(w * (1-progress),0), child:_Panel(page:1-from, count:widget.count)),
      ]));
    });
  }
  @override Widget build(BuildContext context) => Column(children:[
    Container(height:38, color:const Color(0xff243750), alignment:Alignment.center,
      child:Text('NAVEGACIÓN  ·  ${widget.count} elementos', style:const TextStyle(color:Colors.white,fontSize:12,letterSpacing:1))),
    Expanded(child:widget.optimized ? AnimatedBuilder(animation:_motion,builder:(_, __)=>_pages(_motion.value)) : _pages(_motion.value)),
    Container(height:30, color:const Color(0xff243750), alignment:Alignment.center,
      child:const Text('Pantallas A / B  —  1 s por transición', style:TextStyle(color:Colors.white70,fontSize:11))),
  ]);
}
class _Panel extends StatelessWidget {
  const _Panel({required this.page, required this.count});
  final int page, count;
  @override Widget build(BuildContext context) {
    final cols = count <= 10 ? 4 : count <= 30 ? 6 : 10;
    final rows = (count / cols).ceil();
    return ColoredBox(color:page==0?const Color(0xffe1edf6):const Color(0xffe5f4ef), child:LayoutBuilder(builder:(_, c) {
      final cw=c.maxWidth/cols, ch=c.maxHeight/rows;
      return Stack(children:[for(int i=0;i<count;i++) Positioned(
        left:(i%cols)*cw+2, top:(i~/cols)*ch+2, width:cw-4, height:ch-4,
        child:_CardTile(index:i+page, text:'${page==0?'A':'B'}${i+1}', compact:count>10),
      )]);
    }));
  }
}
class _CardTile extends StatelessWidget {
  const _CardTile({required this.index, required this.text, this.compact=false});
  final int index; final String text; final bool compact;
  @override Widget build(BuildContext context) => DecoratedBox(
    decoration:BoxDecoration(color:palette[index%palette.length],borderRadius:BorderRadius.circular(5),
      border:Border.all(color:Colors.black12),boxShadow:const [BoxShadow(color:Colors.black12,blurRadius:2,offset:Offset(0,1))]),
    child:Center(child:Text(text,maxLines:1,overflow:TextOverflow.clip,style:TextStyle(fontSize:compact?9:12,fontWeight:FontWeight.w700,color:const Color(0xff1f3044)))),
  );
}

class ListScene extends StatefulWidget {
  const ListScene({super.key, required this.count, required this.optimized});
  final int count; final bool optimized;
  @override State<ListScene> createState() => _ListSceneState();
}
class _ListSceneState extends State<ListScene> with SingleTickerProviderStateMixin {
  final _scroll=ScrollController();
  late final Ticker _ticker;
  @override void initState() { super.initState(); _ticker=createTicker(_tick)..start(); }
  void _tick(Duration elapsed) {
    if (!_scroll.hasClients || !_scroll.position.hasContentDimensions) return;
    final max=_scroll.position.maxScrollExtent;
    if (max<=0) return;
    final distance=elapsed.inMicroseconds/1000000*600;
    final cycle=distance%(max*2);
    _scroll.jumpTo(cycle<=max?cycle:max*2-cycle);
  }
  @override void dispose() { _ticker.dispose(); _scroll.dispose(); super.dispose(); }
  Widget _row(int i) => _ListRow(index:i);
  @override Widget build(BuildContext context) => ColoredBox(color:const Color(0xffe7edf5),child:
    widget.optimized ? ListView.builder(controller:_scroll,physics:const NeverScrollableScrollPhysics(),padding:EdgeInsets.zero,
      itemExtent:72,itemCount:widget.count,itemBuilder:(_,i)=>_row(i)) :
      ListView(controller:_scroll,physics:const NeverScrollableScrollPhysics(),padding:EdgeInsets.zero,
      itemExtent:72,children:List.generate(widget.count,_row)));
}
class _ListRow extends StatelessWidget {
  const _ListRow({required this.index}); final int index;
  @override Widget build(BuildContext context) => Padding(padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),child:DecoratedBox(
    decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xffd1deea)),borderRadius:BorderRadius.circular(8)),
    child:Row(children:[const SizedBox(width:9),SizedBox(width:42,height:42,child:_CardTile(index:index,text:'${index+1}',compact:true)),
      const SizedBox(width:10),Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Registro ${index+1}',style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),
        Text('Elemento gráfico local · ${index%7+1}',style:const TextStyle(fontSize:11,color:Colors.black54)),
      ])),const Icon(Icons.chevron_right,size:16),const SizedBox(width:8)]),
  ));
}

class TransformScene extends StatefulWidget {
  const TransformScene({super.key, required this.count, required this.optimized});
  final int count; final bool optimized;
  @override State<TransformScene> createState() => _TransformSceneState();
}
class _TransformSceneState extends State<TransformScene> with SingleTickerProviderStateMixin {
  late final AnimationController _motion;
  late final List<double> _phases;
  @override void initState() {
    super.initState();
    final random=math.Random(2026);
    _phases=List.generate(widget.count,(_)=>random.nextDouble()*2*math.pi);
    _motion=AnimationController(vsync:this,duration:const Duration(seconds:2))..repeat();
  }
  @override void dispose() { _motion.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ColoredBox(color:const Color(0xffe5edf5),child:LayoutBuilder(builder:(_,c){
    final cols=math.sqrt(widget.count).ceil(), rows=(widget.count/cols).ceil();
    final cw=c.maxWidth/cols, ch=c.maxHeight/rows, size=math.min(cw,ch)*.53;
    return ClipRect(child:Stack(children:[for(int i=0;i<widget.count;i++) Positioned(
      left:(i%cols)*cw+(cw-size)/2, top:(i~/cols)*ch+(ch-size)/2, width:size,height:size,
      child:AnimatedBuilder(animation:_motion, child:widget.optimized?_CardTile(index:i,text:'${i+1}',compact:true):null,
        builder:(_,child){
          final t=_motion.value*2*math.pi+_phases[i];
          return Transform.translate(offset:Offset(math.sin(t)*cw*.12,math.cos(t)*ch*.12),child:
            Transform.rotate(angle:t,child:Transform.scale(scale:1+.12*math.sin(t),child:child??_CardTile(index:i,text:'${i+1}',compact:true))));
        }),
    )]));
  }));
}
