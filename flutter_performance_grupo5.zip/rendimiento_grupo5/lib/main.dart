import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'benchmark.dart';
import 'platform/storage.dart' as storage;
import 'protocol.dart';

void main()=>runApp(const ResearchApp());
class ResearchApp extends StatelessWidget {
  const ResearchApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(title:'Flutter Performance Lab · Grupo 5',debugShowCheckedModeBanner:false,
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff155d82)),useMaterial3:true),home:const LabHome());
}
class LabHome extends StatefulWidget {
  const LabHome({super.key});
  @override State<LabHome> createState()=>_LabHomeState();
}
class _LabHomeState extends State<LabHome> with WidgetsBindingObserver {
  static const _metaLabels=<String,String>{'device':'Equipo / identificador','cpu':'CPU','gpu':'GPU','ram':'RAM física','os':'Sistema operativo',
    'flutter_dart':'Versiones Flutter / Dart','browser':'Versión Chrome (solo web)','renderer':'Renderizador efectivo','refresh_hz':'Frecuencia fija (Hz)',
    'commit':'Commit Git (o identificador de revisión)','operator':'Operador','energy':'Modo de energía'};
  final _meta=<String,TextEditingController>{for(final k in _metaLabels.keys) k:TextEditingController()};
  final _rows=<Map<String,dynamic>>[];
  final _enabled=<Scenario,bool>{for(final s in Scenario.values)s:true};
  Phase _phase=Phase.pilot;
  bool _ready=false,_busy=false,_stateError=false,_locked=false;
  String _message='';
  DateTime? _lastEnd;
  int _attemptCount=0;
  Timer? _timer;
  String get _platform=>kIsWeb?'web':'android';
  bool get _isProfile=>kProfileMode;
  List<Trial> get _plan=>plan(_phase);
  bool _completed(Trial t)=>_rows.any((r)=>r['id']==t.id&&r['status']!='invalid');
  Trial? get _next {for(final t in _plan){if(!_completed(t))return t;}return null;}
  int get _wait {if(_lastEnd==null)return 0;final pause=_attemptCount>0&&_attemptCount%9==0?blockCooldown:cooldown;final s=pause.inSeconds-DateTime.now().toUtc().difference(_lastEnd!).inSeconds;return s>0?s:0;}
  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);_restore();_timer=Timer.periodic(const Duration(seconds:1),(_){if(mounted&&!_busy&&_lastEnd!=null)setState((){});});}
  Future<void> _restore() async {
    try{final text=await storage.loadState();if(text!=null){
      final m=jsonDecode(text) as Map<String,dynamic>;
      for(final r in (m['rows'] as List? ?? [])){_rows.add(Map<String,dynamic>.from(r as Map));}
      final meta=Map<String,dynamic>.from(m['meta'] as Map? ?? {});for(final e in _meta.entries){e.value.text=meta[e.key]?.toString()??'';}
      final flags=m['enabled'] as Map? ?? {};for(final s in Scenario.values){_enabled[s]=flags[s.name] as bool? ?? true;}
      _locked=m['locked']==true;_phase=Phase.values.firstWhere((p)=>p.name==m['phase'],orElse:()=>Phase.pilot);
      _attemptCount=m['attemptCount'] as int? ?? _rows.length;
      _lastEnd=DateTime.tryParse(m['lastEnd']?.toString()??'');
      if(m['pending'] is Map){final r=Map<String,dynamic>.from(m['pending'] as Map);r['status']='invalid';r['reason']='Aplicación cerrada antes de finalizar la ejecución';_rows.add(r);_attemptCount++;_lastEnd=DateTime.now().toUtc();await _persist();}
    }}catch(e){_message='No se pudo leer el almacenamiento: $e. No comience pruebas hasta solucionarlo.';_stateError=true;}
    if(mounted)setState(()=>_ready=true);
  }
  Map<String,String> _metadata()=>{for(final e in _meta.entries)e.key:e.value.text.trim()};
  Future<void> _persist({Map<String,dynamic>? pending})=>storage.saveState(jsonEncode({'rows':_rows,'meta':_metadata(),'enabled':{for(final e in _enabled.entries)e.key.name:e.value},'locked':_locked,'phase':_phase.name,'lastEnd':_lastEnd?.toIso8601String(),'attemptCount':_attemptCount,'pending':pending}));
  Future<void> _saveSettings() async {try{await _persist();if(mounted)setState(()=>_message='Configuración guardada.');}catch(e){if(mounted)setState(()=>_message='No se pudo guardar: $e');}}
  bool get _configured => _meta.entries.every((e)=> (e.key=='browser'&&!kIsWeb)||e.value.text.trim().isNotEmpty) && (double.tryParse(_meta['refresh_hz']!.text.trim())??0)>0;
  bool get _pilotDone=>plan(Phase.pilot).every(_completed);
  bool get _isolatedDone=>plan(Phase.isolated).every(_completed);
  String get _strategies=>Scenario.values.where((s)=>_enabled[s]==true).map((s)=>s.treatment.label).join('+');
  Future<void> _start({bool preview=false}) async {
    final t=_next??_plan.first;
    if(_busy)return;
    if(!preview&&(!_isProfile||!_configured||_wait>0||_next==null||_stateError))return;
    if(!preview&&_phase==Phase.isolated&&!_pilotDone){setState(()=>_message='Complete primero el piloto local.');return;}
    if(!preview&&_phase==Phase.main&&!_locked){setState(()=>_message='Primero evalúe las estrategias en ambos entornos y congele Vopt.');return;}
    final opt=t.variant==Variant.vopt?(_enabled[t.scenario]??false):t.variant.optimizes(t.scenario);
    if(preview){await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>BenchmarkPage(trial:t,attempt:0,hz:60,optimized:opt,preview:true)));return;}
    final attempt=_rows.where((r)=>r['id']==t.id).length+1;
    final media=MediaQuery.of(context);
    final data=<String,dynamic>{..._metadata(),'id':t.id,'attempt':attempt,'phase':t.phase.name,'platform':_platform,'scenario':t.scenario.name,'load':t.load.name,
      'elements':t.elements,'version':t.variant.label,'rep':t.repetition,'pair_order':t.order,'run_order':_attemptCount+1,
      'resolution':'${(media.size.width*media.devicePixelRatio).round()}x${(media.size.height*media.devicePixelRatio).round()} viewport físico',
      'dpr':media.devicePixelRatio,'build_mode':'profile','integrated_strategy':t.variant==Variant.vopt?(_strategies.isEmpty?'none':_strategies):'',
      'heap_type':kIsWeb?'javascript_heap':'dart_heap','status':'pending','trace_file':'','memory_file':''};
    setState(()=>_busy=true);
    try{
      await _persist(pending:data);
      if(!mounted)return;
      final result=await Navigator.of(context).push<Map<String,dynamic>>(MaterialPageRoute(builder:(_)=>BenchmarkPage(trial:t,attempt:attempt,hz:double.parse(_meta['refresh_hz']!.text.trim()),optimized:opt,preview:false)));
      data.addAll(result??{'status':'invalid','reason':'Ejecución cerrada sin resultados'});
      _rows.add(data);_attemptCount++;_lastEnd=DateTime.now().toUtc();await _persist();
      if(mounted)setState(()=>_message=data['status']=='invalid'?'Ejecución inválida; se repetirá.':'Registro guardado. Exporte y vincule las trazas externas; no es aún un dato validado.');
    }catch(e){if(mounted)setState(()=>_message='Error de almacenamiento: $e. Exporte los datos antes de cerrar.');}
    finally{if(mounted)setState(()=>_busy=false);}
  }
  Future<void> _invalidate(Map<String,dynamic> row) async {
    final ctrl=TextEditingController();
    final reason=await showDialog<String>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Invalidar ejecución'),content:TextField(controller:ctrl,decoration:const InputDecoration(labelText:'Motivo técnico obligatorio'),maxLines:3),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:(){if(ctrl.text.trim().isNotEmpty)Navigator.pop(ctx,ctrl.text.trim());},child:const Text('Invalidar'))]));
    ctrl.dispose();if(reason==null||!mounted)return;
    setState((){row['status']='invalid';row['reason']=reason;});await _saveSettings();
  }
  Future<void> _export(bool raw) async {
    try{final data=raw?await storage.readRaw():toCsv(_rows);if(!mounted)return;
      final ok=await storage.saveFile(raw?'frames_android.csv':'resultados_$_platform.csv',data);
      if(mounted)setState(()=>_message=ok?'Archivo exportado.':'Exportación cancelada.');
    }catch(e){if(mounted)setState(()=>_message='No se pudo exportar: $e. Use Copiar CSV para el resumen.');}
  }
  @override void didChangeAppLifecycleState(AppLifecycleState state){/* Las interrupciones se revisan con la traza y la bitácora. */}
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);_timer?.cancel();for(final c in _meta.values){c.dispose();}super.dispose();}
  @override Widget build(BuildContext context){
    final t=_next;final completed=_plan.where(_completed).length;
    return Scaffold(appBar:AppBar(title:const Text('Performance Lab · Grupo 5')),body:!_ready?const Center(child:CircularProgressIndicator()):SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:900),child:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Rendimiento móvil vs. web',style:Theme.of(context).textTheme.headlineSmall),
      Text('${kIsWeb?'Chrome / web':'Android físico'} · ${_isProfile?'Modo profile':'Modo no profile — solo vista previa'}'),const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('1. Ficha del entorno',style:TextStyle(fontWeight:FontWeight.bold)),
        const Text('Complete antes de medir. Conserve la misma configuración y puerto web. No modifique los datos durante el estudio.'),
        ExpansionTile(title:Text(_configured?'Ficha completa':'Completar ficha técnica'),children:[for(final e in _metaLabels.entries)if(e.key!='browser'||kIsWeb)Padding(padding:const EdgeInsets.symmetric(vertical:4),child:TextField(controller:_meta[e.key],enabled:!_busy,keyboardType:e.key=='refresh_hz'?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,decoration:InputDecoration(labelText:e.value,border:const OutlineInputBorder()),onChanged:(_)=>setState((){}))),
          Align(alignment:Alignment.centerRight,child:TextButton(onPressed:_busy?null:_saveSettings,child:const Text('Guardar ficha')))]),
      ]))),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('2. Fase experimental',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),
        DropdownButtonFormField<Phase>(initialValue:_phase,decoration:const InputDecoration(border:OutlineInputBorder()),items:[for(final p in Phase.values)DropdownMenuItem(value:p,child:Text(p.label))],onChanged:_busy?null:(p){if(p!=null){setState(()=>_phase=p);_saveSettings();}}),
        const SizedBox(height:10),LinearProgressIndicator(value:completed/_plan.length),const SizedBox(height:5),Text('$completed / ${_plan.length} registros en esta fase (sin validar evidencia)'),
        const SizedBox(height:8),Text('Siguiente: ${t==null?'fase terminada':'${t.scenario.label} · ${t.load.label} · ${t.variant.label} · rep. ${t.repetition} (${t.elements})'}'),
        if(_phase==Phase.main) ...[const Divider(),const Text('Vopt: seleccione solo estrategias aprobadas tras analizar el piloto y las pruebas aisladas de AMBOS entornos.'),
          for(final s in Scenario.values)CheckboxListTile(contentPadding:EdgeInsets.zero,title:Text('${s.treatment.label} — ${s.label}'),value:_enabled[s],onChanged:_locked||_busy?null:(v)=>setState(()=>_enabled[s]=v??false)),
          Text(_locked?'Configuración Vopt congelada.':'Se requiere completar las pruebas aisladas locales y revisar ambos entornos.'),
          if(!_locked)OutlinedButton(onPressed:!_isolatedDone||_busy?null:()async{setState(()=>_locked=true);await _saveSettings();},child:const Text('Congelar Vopt (confirmo revisión de ambos entornos)'))],
        if(_wait>0)Text('Descanso obligatorio: $_wait s',style:const TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:10),Wrap(spacing:10,runSpacing:8,children:[FilledButton.icon(onPressed:_busy||!_isProfile||!_configured||_wait>0||t==null||_stateError||(_phase==Phase.main&&!_locked)?null:()=>_start(),icon:const Icon(Icons.play_arrow),label:const Text('Iniciar siguiente prueba')),
          OutlinedButton(onPressed:_busy?null:()=>_start(preview:true),child:const Text('Vista previa sin datos'))]),
        const SizedBox(height:8),const Text('10 s de calentamiento · 30 s medidos · descanso mínimo de 30 s; 5 min cada nueve intentos. Reinicie la aplicación / pestaña entre pruebas. Mantenga DevTools registrando antes de iniciar.'),
      ]))),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('3. Resultados y evidencia',style:TextStyle(fontWeight:FontWeight.bold)),Text('${_rows.length} intentos guardados en este entorno.'),
        Wrap(spacing:8,runSpacing:6,children:[FilledButton.tonal(onPressed:_busy||_rows.isEmpty?null:()=>_export(false),child:const Text('Exportar CSV')),
          if(!kIsWeb)OutlinedButton(onPressed:_busy||_rows.isEmpty?null:()=>_export(true),child:const Text('Exportar cuadros Android')),
          TextButton(onPressed:_busy||_rows.isEmpty?null:()async{await Clipboard.setData(ClipboardData(text:toCsv(_rows)));if(mounted)setState(()=>_message='Resumen copiado al portapapeles.');},child:const Text('Copiar CSV'))]),
        if(_message.isNotEmpty)Text(_message),const Divider(),
        for(final r in _rows.reversed.take(12))ListTile(contentPadding:EdgeInsets.zero,title:Text('${r['id']} · a${r['attempt']}',style:const TextStyle(fontSize:13)),subtitle:Text('${r['status']} · ${r['fps_engine']==null?'FPS externo / no disponible':'FPS motor: ${(r['fps_engine'] as num).toStringAsFixed(2)}'}'),trailing:r['status']=='invalid'?null:IconButton(tooltip:'Invalidar por incidencia',onPressed:_busy?null:()=>_invalidate(r),icon:const Icon(Icons.flag_outlined))),
        const Text('Se muestran los últimos 12 intentos; el CSV conserva todos. Los indicadores de Chrome y memoria se completan desde DevTools. No se generan cifras ficticias.'),
      ]))),
    ])))));
  }
}
