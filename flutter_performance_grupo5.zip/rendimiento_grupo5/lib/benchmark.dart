import 'dart:async';
import 'dart:ui' show FrameTiming, FramePhase;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'platform/storage.dart' as storage;
import 'protocol.dart';
import 'scenarios.dart';

class BenchmarkPage extends StatefulWidget {
  const BenchmarkPage({super.key,required this.trial,required this.attempt,required this.hz,required this.optimized,required this.preview});
  final Trial trial;
  final int attempt;
  final double hz;
  final bool optimized,preview;
  @override State<BenchmarkPage> createState()=>_BenchmarkPageState();
}
class _BenchmarkPageState extends State<BenchmarkPage> with WidgetsBindingObserver {
  final _captured=<FrameTiming>[];
  late final Widget _scene;
  bool _active=true,_listening=false,_done=false,_interrupted=false;
  String _stage='Preparando escenario';
  DateTime? _startUtc,_endUtc;
  int? _startUs,_endUs;
  final _watch=Stopwatch();
  String get _tag=>'G5_${widget.trial.id}_a${widget.attempt}';
  @override void initState(){
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scene=scenarioWidget(widget.trial,optimized:widget.optimized);
    WidgetsBinding.instance.addPostFrameCallback((_) { if(mounted) { if(widget.preview){setState(()=>_stage='Vista previa · no se registra');}else{_run();} } });
  }
  void _collect(List<FrameTiming> frames){if(_active)_captured.addAll(frames);}
  Future<int> _boundary() {
    final c=Completer<int>();
    SchedulerBinding.instance.scheduleFrameCallback((_){
      c.complete(SchedulerBinding.instance.currentSystemFrameTimeStamp.inMicroseconds);
    });
    return c.future;
  }
  void _unlisten(){if(_listening){SchedulerBinding.instance.removeTimingsCallback(_collect);_listening=false;}}
  Future<void> _run() async {
    try {
      if(!kIsWeb){SchedulerBinding.instance.addTimingsCallback(_collect);_listening=true;}
      setState(()=>_stage='Calentamiento · 10 s');
      await Future<void>.delayed(warmup);
      if(!_active||!mounted)return;
      _startUs=await _boundary();
      if(!_active||!mounted)return;
      _startUtc=DateTime.now().toUtc();_watch.start();
      storage.mark('${_tag}_START');
      setState(()=>_stage='Midiendo · 30 s');
      await Future<void>.delayed(measure);
      if(!_active||!mounted)return;
      _endUs=await _boundary();
      if(!_active||!mounted)return;
      _watch.stop();_endUtc=DateTime.now().toUtc();
      storage.mark('${_tag}_END');
      setState(()=>_stage='Finalizando registro · 2 s');
      await Future<void>.delayed(const Duration(seconds:2));
      if(!_active||!mounted)return;
      _unlisten();
      final duration=(_endUs!-_startUs!)/1000000;
      final fields=<String,dynamic>{'started_utc':_startUtc!.toIso8601String(),'ended_utc':_endUtc!.toIso8601String(),
        'window_s':kIsWeb?_watch.elapsedMicroseconds/1000000:duration,
        'status':'pending_review','notes':'Marcadores ${_tag}_START / ${_tag}_END; reloj local ${_watch.elapsedMilliseconds} ms.'};
      if(!kIsWeb){
        final frames=_captured.where((f){final ts=f.timestampInMicroseconds(FramePhase.vsyncStart);return ts>=_startUs!&&ts<_endUs!;}).toList()
          ..sort((a,b)=>a.timestampInMicroseconds(FramePhase.vsyncStart).compareTo(b.timestampInMicroseconds(FramePhase.vsyncStart)));
        if(frames.isEmpty||duration<=0){fields['notes']='Sin FrameTiming dentro de la ventana; revisar trazas y reloj. No se asignaron valores cero.';}
        else {
          final b=frames.map((f)=>f.buildDuration.inMicroseconds/1000).toList();
          final r=frames.map((f)=>f.rasterDuration.inMicroseconds/1000).toList();
          final budget=1000/widget.hz;
          int exceeded=0;
          for(int i=0;i<frames.length;i++){if(b[i]>budget||r[i]>budget)exceeded++;}
          fields.addAll({'frames_engine':frames.length,'fps_engine':frames.length/duration,
            'build_median_ms':quantile(b,.5),'build_p95_ms':quantile(b,.95),'raster_median_ms':quantile(r,.5),'raster_p95_ms':quantile(r,.95),
            'engine_exceeded_count':exceeded,'engine_exceeded_pct':100*exceeded/frames.length});
        }
        // Preserve all captured timing rows, including excluded warm-up/drain rows, for auditing.
        final raw=StringBuffer();
        for(final f in _captured){
          final ts=f.timestampInMicroseconds(FramePhase.vsyncStart);
          raw.writeln('${widget.trial.id},${widget.attempt},$ts,${_startUs!},${_endUs!},${ts>=_startUs!&&ts<_endUs!?1:0},${f.buildDuration.inMicroseconds/1000},${f.rasterDuration.inMicroseconds/1000},${f.totalSpan.inMicroseconds/1000}');
        }
        try{await storage.writeRaw('${widget.trial.id}_a${widget.attempt}',raw.toString());fields['raw_file']='frames_android.csv#${widget.trial.id}_a${widget.attempt}';}
        catch(e){fields['notes']='${fields['notes']} Error al escribir cuadros: $e';}
      }
      if(!mounted||!_active)return;
      _done=true;Navigator.of(context).pop(fields);
    }catch(e){if(mounted&&_active)_abort('Error de instrumentación: $e');}
  }
  void _abort(String reason){
    if(_done)return;_active=false;_unlisten();_done=true;
    if(widget.preview){Navigator.of(context).pop();return;}
    if(_startUtc!=null&&_endUtc==null){try{storage.mark('${_tag}_ABORT');}catch(_){} }
    Navigator.of(context).pop(<String,dynamic>{'status':'invalid','reason':reason,'started_utc':_startUtc?.toIso8601String(),'ended_utc':DateTime.now().toUtc().toIso8601String()});
  }
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(!widget.preview&&!_done&&(state==AppLifecycleState.hidden||state==AppLifecycleState.paused||state==AppLifecycleState.detached)){
      _interrupted=true;_active=false;_unlisten();
    }
    if(state==AppLifecycleState.resumed&&_interrupted&&!_done){
      WidgetsBinding.instance.addPostFrameCallback((_) {if(mounted&&!_done)_abort('La aplicación dejó de estar visible');});
    }
  }
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);_active=false;_unlisten();super.dispose();}
  @override Widget build(BuildContext context)=>PopScope(canPop:false,child:Scaffold(
    appBar:AppBar(automaticallyImplyLeading:false,title:Text('${widget.trial.variant.label} · ${widget.trial.load.label}'),actions:[TextButton(onPressed:()=>_abort('Interrumpida por el operador'),child:const Text('Detener'))]),
    body:SafeArea(child:LayoutBuilder(builder:(context,c){
      if(c.maxWidth<viewportWidth||c.maxHeight<viewportHeight+70){if(!widget.preview&&!_done){WidgetsBinding.instance.addPostFrameCallback((_) {if(mounted&&!_done)_abort('Área visible insuficiente');});}return Center(child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[const Text('El área visible no admite 320 × 320 píxeles lógicos y controles. Use orientación vertical, zoom normal o una ventana más grande.'),TextButton(onPressed:()=>_abort('Área visible insuficiente'),child:const Text('Invalidar'))])));}
      return Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
        Text(_stage,style:Theme.of(context).textTheme.titleMedium),const SizedBox(height:10),
        SizedBox(width:viewportWidth,height:viewportHeight,child:ClipRect(child:_scene)),const SizedBox(height:10),
        Text('${widget.trial.scenario.label} · ${widget.trial.elements}',style:Theme.of(context).textTheme.bodySmall),
      ]));
    })),
  ));
}
