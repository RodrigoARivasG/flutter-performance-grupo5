import 'dart:math';

const viewportWidth = 320.0;
const viewportHeight = 320.0;
const warmup = Duration(seconds: 10);
const measure = Duration(seconds: 30);
const cooldown = Duration(seconds: 30);
const blockCooldown = Duration(minutes: 5);

enum Scenario { transitions, lists, transforms }
enum Load { low, medium, high }
enum Phase { pilot, isolated, main, exploratory }
enum Variant { v0, v1, v2, v3, vopt }

extension ScenarioLabel on Scenario {
  String get label => switch (this) {
    Scenario.transitions => 'Transiciones de pantalla',
    Scenario.lists => 'Listas extensas',
    Scenario.transforms => 'Transformaciones simultáneas',
  };
  int elements(Load load) => switch (this) {
    Scenario.transitions => [10, 30, 60][load.index],
    Scenario.lists => [100, 500, 1000][load.index],
    Scenario.transforms => [20, 60, 120][load.index],
  };
  Variant get treatment => [Variant.v1, Variant.v2, Variant.v3][index];
}
extension LoadLabel on Load {
  String get label => ['Baja', 'Media', 'Alta'][index];
}
extension PhaseLabel on Phase {
  String get label => ['Piloto', 'Estrategias aisladas', 'Comparación principal', 'Cierre exploratorio (3 pruebas)'][index];
}
extension VariantLabel on Variant {
  String get label => ['V0', 'V1', 'V2', 'V3', 'Vopt'][index];
  bool optimizes(Scenario s) => this == s.treatment || this == Variant.vopt;
}

class Trial {
  const Trial(this.phase, this.scenario, this.load, this.variant, this.repetition, this.order);
  final Phase phase;
  final Scenario scenario;
  final Load load;
  final Variant variant;
  final int repetition;
  final int order;
  String get id => '${phase.name}_${scenario.name}_${load.name}_${variant.label}_r$repetition';
  int get elements => scenario.elements(load);
}

/// Fixed randomized pair order. Positions within each pair alternate by repetition.
List<Trial> plan(Phase phase) {
  // Cierre reducido: una medición por estrategia con carga alta.
  // Las referencias V0 provienen del piloto ya ejecutado.
  if (phase == Phase.exploratory) {
    return [for (final s in Scenario.values)
      Trial(phase, s, Load.high, s.treatment, 1, 1)];
  }
  final random = Random(2509642022 + phase.index);
  final pairs = <List<Trial>>[];
  final int reps = phase == Phase.pilot ? 1 : phase == Phase.isolated ? 3 : 5;
  for (final scenario in Scenario.values) {
    for (final load in (phase == Phase.isolated ? [Load.high] : Load.values)) {
      for (int r = 1; r <= reps; r++) {
        final treatment = phase == Phase.isolated ? scenario.treatment : Variant.vopt;
        final variants = phase == Phase.pilot ? [Variant.v0] :
            (r.isOdd ? [Variant.v0, treatment] : [treatment, Variant.v0]);
        pairs.add([for (int i = 0; i < variants.length; i++)
          Trial(phase, scenario, load, variants[i], r, i + 1)]);
      }
    }
  }
  pairs.shuffle(random);
  return pairs.expand((p) => p).toList(growable: false);
}

const columns = <String>[
  'id','attempt','phase','platform','scenario','load','elements','version','rep','pair_order','run_order',
  'started_utc','ended_utc','window_s','status','reason','device','cpu','gpu','ram','os','flutter_dart',
  'browser','renderer','refresh_hz','commit','operator','resolution','dpr','build_mode','energy','integrated_strategy',
  'frames_engine','fps_engine','build_median_ms','build_p95_ms','raster_median_ms','raster_p95_ms',
  'engine_exceeded_count','engine_exceeded_pct','web_complete_frames','web_total_frames','web_discarded_frames',
  'web_partial_frames','fps_web','web_frame_median_ms','web_frame_p95_ms','web_discarded_pct','web_partial_pct',
  'heap_initial_mib','heap_peak_mib','heap_final_mib','heap_type','memory_sample_s','rss_initial_mib','rss_peak_mib','rss_final_mib',
  'trace_file','memory_file','raw_file','notes'
];
String csvCell(Object? v) {
  final s = v?.toString() ?? '';
  return '"${s.replaceAll('"', '""')}"';
}
String toCsv(List<Map<String,dynamic>> rows) => [
  columns.join(','),
  ...rows.map((r) => columns.map((k) => csvCell(r[k])).join(','))
].join('\r\n');

double? quantile(List<double> values, double p) {
  if (values.isEmpty) return null;
  final sorted = [...values]..sort();
  final pos = (sorted.length - 1) * p;
  final a = pos.floor();
  final b = pos.ceil();
  return sorted[a] + (sorted[b] - sorted[a]) * (pos - a);
}
