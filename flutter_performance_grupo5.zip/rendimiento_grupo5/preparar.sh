#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
flutter create --no-pub --platforms=android,web --org sv.edu.utec --project-name rendimiento_grupo5 "$tmp"
for dir in android web; do [ -d "$dir" ] || cp -R "$tmp/$dir" .; done
[ -f .metadata ] || cp "$tmp/.metadata" .
cp tool/android/MainActivity.kt android/app/src/main/kotlin/sv/edu/utec/rendimiento_grupo5/MainActivity.kt
flutter pub get
