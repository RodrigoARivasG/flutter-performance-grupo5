$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter no está en PATH. Abra una terminal configurada con Flutter.' }
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('grupo5_' + [guid]::NewGuid().ToString('N'))
try {
    flutter create --no-pub --platforms=android,web --org sv.edu.utec --project-name rendimiento_grupo5 $tmp
    if ($LASTEXITCODE -ne 0) { throw 'flutter create falló.' }
    foreach ($dir in @('android','web')) {
        if (-not (Test-Path $dir)) { Copy-Item (Join-Path $tmp $dir) . -Recurse }
    }
    if (-not (Test-Path '.metadata')) { Copy-Item (Join-Path $tmp '.metadata') . }
    $target = 'android/app/src/main/kotlin/sv/edu/utec/rendimiento_grupo5/MainActivity.kt'
    if (-not (Test-Path (Split-Path $target))) { throw 'El proyecto Android no tiene el paquete esperado; revise la carpeta android.' }
    Copy-Item 'tool/android/MainActivity.kt' $target -Force
    flutter pub get
    if ($LASTEXITCODE -ne 0) { throw 'flutter pub get falló.' }
    Write-Host 'Proyecto preparado. Ejecute flutter analyze y flutter test.'
} finally { if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force } }
