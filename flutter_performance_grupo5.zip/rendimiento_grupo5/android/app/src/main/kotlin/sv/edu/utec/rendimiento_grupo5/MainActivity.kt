package sv.edu.utec.rendimiento_grupo5

import android.app.Activity
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val channel = "sv.edu.utec.rendimiento/export"
    private var pending: MethodChannel.Result? = null
    private var payload: String? = null
    private val exportRequest = 5081
    private val stateFile get() = File(filesDir, "grupo5_state.json")
    private val rawDir get() = File(filesDir, "grupo5_frames").apply { mkdirs() }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "loadState" -> result.success(if (stateFile.exists()) stateFile.readText() else null)
                    "saveState" -> {
                        val tmp = File(filesDir, "grupo5_state.tmp")
                        tmp.writeText(call.arguments as String)
                        check(tmp.renameTo(stateFile)) { "No se pudo actualizar la bitácora" }
                        result.success(null)
                    }
                    "writeRaw" -> {
                        val id = call.argument<String>("id") ?: error("Falta identificador")
                        require(id.matches(Regex("[A-Za-z0-9_]+")))
                        File(rawDir, "$id.csv").writeText(call.argument<String>("data") ?: "")
                        result.success(null)
                    }
                    "readRaw" -> result.success(buildString {
                        appendLine("id,attempt,vsync_us,start_us,end_us,in_window,build_ms,raster_ms,total_span_ms")
                        rawDir.listFiles()?.filter { it.extension == "csv" }?.sortedBy { it.name }?.forEach { append(it.readText()) }
                    })
                    "export" -> {
                        check(pending == null) { "Ya se está exportando un archivo" }
                        val name = call.argument<String>("name") ?: "resultados.csv"
                        payload = call.argument<String>("data") ?: ""
                        pending = result
                        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "text/csv"
                            putExtra(Intent.EXTRA_TITLE, name)
                        }
                        try { startActivityForResult(intent, exportRequest) }
                        catch (e: Exception) { pending = null; payload = null; throw e }
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) { result.error("STORAGE", e.message, null) }
        }
    }
    @Deprecated("Android legacy activity result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != exportRequest) return
        val callback = pending ?: return
        try {
            val uri = data?.data
            if (resultCode != Activity.RESULT_OK || uri == null) { callback.success(false); return }
            val stream = contentResolver.openOutputStream(uri) ?: error("No se pudo abrir el destino")
            stream.use { it.write((payload ?: "").toByteArray(Charsets.UTF_8)) }
            callback.success(true)
        } catch (e: Exception) { callback.error("EXPORT", e.message, null) }
        finally { pending = null; payload = null }
    }
}
