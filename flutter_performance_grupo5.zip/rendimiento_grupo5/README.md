# Performance Lab · Grupo 5

Prototipo para **Evaluación de métricas de rendimiento (Performance) y optimización de animaciones complejas en el renderizado móvil vs. web**, Técnicas de Calidad de Software. Basado en los avances 1 y 2. No contiene mediciones simuladas.

## 1. Preparación en Windows

1. Descomprime el ZIP. Abre la carpeta `rendimiento_grupo5` en VS Code y abre su terminal PowerShell.
2. Verifica `flutter --version` y `flutter doctor`. Necesitas Flutter 3.35 o posterior con Dart 3.9 o posterior, Chrome y, para Android, Android SDK/JDK y un dispositivo físico con depuración USB.
3. Ejecuta:

```powershell
powershell -ExecutionPolicy Bypass -File .\preparar.ps1
flutter analyze
flutter test
```

El script genera las carpetas Android y web usando **tu SDK de Flutter**, copia la integración nativa de exportación y ejecuta `flutter pub get`. No modifica el código Dart. Es necesario porque el paquete distribuye el código fuente y no incluye binarios ni archivos generados por un SDK. En Linux/macOS: `bash preparar.sh`.

## 2. Ejecutar

Primero puedes abrir en debug únicamente para comprobar la interfaz:

```powershell
flutter run -d chrome
```

Utiliza **Vista previa sin datos**. No se habilitan las mediciones en debug ni release.

Para las mediciones web usa siempre el mismo puerto (la bitácora persiste en el origen de Chrome):

```powershell
flutter run --profile -d chrome --web-port=8080
```

Para móvil, conecta el Android físico con USB, autoriza la depuración y ejecuta:

```powershell
flutter devices
flutter run --profile -d ID_REAL_DE_ANDROID
```

Sustituye `ID_REAL_DE_ANDROID` por el ID real de `flutter devices`. En el primer uso puede ser necesario `flutter doctor --android-licenses`. No utilices un emulador para los datos definitivos. Si Chrome no abre en profile, revisa el SDK y usa una instalación compatible; no reemplaces profile por debug. El web está pensado para la compilación JavaScript por defecto, no `--wasm`.

## 3. Qué contiene

| Escenario | Baja | Media | Alta | Estrategia |
|---|---:|---:|---:|---|
| Transiciones entre dos páginas | 10 | 30 | 60 | V1: reconstrucción localizada |
| Listas (filas de 72 px y 600 px lógicos/s) | 100 | 500 | 1000 | V2: ListView.builder |
| Figuras (rotación, escala, traslación, ciclo de 2 s) | 20 | 60 | 120 | V3: child de AnimatedBuilder |

V0 es la línea base; V1, V2 y V3 son cambios aislados respecto de V0. Vopt aplica las estrategias seleccionadas y congeladas tras revisar ambos entornos. El área lógica común es 320 × 320; las páginas de transición se representan mediante una transición personalizada de paneles deslizantes, de 1 s por cambio. Las cargas, gráficos locales y lógica de movimiento se mantienen iguales en las variantes. Las listas se desplazan sin interacción manual y las figuras usan semilla fija.

Por entorno: piloto 9, aislamiento 18 y comparación principal 90; en total, para Android y web, 18 + 36 + 180 = 234 ejecuciones planificadas, de las que 216 corresponden al estudio definitivo. Cada intento conserva su identificador, orden, versión, repetición, incidencias y metadatos. Los pares alternan orden y su secuencia se pseudoaleatoriza con semilla fija. Cada ejecución: 10 s para calentar + 30 s para medir + 2 s de recepción de datos; descanso mínimo de 30 s (5 min cada nueve intentos). Reinicia la app o pestaña entre intentos, sin borrar datos. Si hay interrupciones o pérdida de datos, invalida con motivo y repite. No descartes valores lentos por ser lentos.

## 4. Recolección (lee `docs/GUIA_PRUEBAS.md` antes de medir)

- En Android se registran automáticamente los FrameTiming del motor, FPS operacionales, mediana/p95 de UI y raster y porcentaje de etapas excedidas. El piloto debe verificar que los timestamps de inicio/fin y vsync pertenecen al mismo reloj y que los cuadros se recuperan completos. Si no es así, usa las trazas de DevTools y deja sin dato el contador que no puedas comprobar.
- En Chrome se emiten marcas `G5_..._START` y `G5_..._END` en Performance. La traza del navegador es la fuente de cuadros y duraciones; no se usan los tiempos Flutter de web como si fueran Android.
- Heap y RSS son contadores externos: registra las series reales en las herramientas correspondientes. El programa no inventa memoria, no mide GPU/batería y no deduce FPS a partir de buildDuration.
- Exporta el CSV de cada entorno y el CSV de cuadros Android; conserva las trazas. Edita una **copia** de los CSV para completar contadores externos y marcar `valid` solo tras la revisión. Utiliza punto como separador decimal. Conserva vacíos los datos no disponibles y explica su causa.

## 5. Tablas y gráficos para el informe

Con Python instalado, en la terminal:

```powershell
python -m pip install -r tool/requirements.txt
python tool/analizar.py resultados_android_revisado.csv resultados_web_revisado.csv --out analisis
```

El script solo toma registros `valid`, separa piloto de análisis, resume cada métrica por condición (media, DE, mediana, rango, n) y compara pares V0 vs. Vopt o estrategia aislada. También genera gráficos PNG separados para cada plataforma e indicador, tablas con diferencias absolutas y relativas y cobertura del protocolo. La memoria web y Android se mantienen separadas. No declara significancia estadística.

## 6. Estado técnico

Código fuente entregado sin SDK Flutter disponible en el entorno de generación: no se ha compilado ni ejecutado allí. Se incluyen pruebas unitarias de la matriz, orden, cargas, cuantiles y CSV para que las ejecutes localmente. Antes de recolectar resultados, confirma `flutter analyze`, `flutter test`, arranque profile en ambos destinos y piloto; registra cualquier corrección y congela el código y protocolo. Las pruebas de rendimiento reales, capturas, repositorio remoto y conclusiones empíricas deben obtenerse en los equipos del grupo.
