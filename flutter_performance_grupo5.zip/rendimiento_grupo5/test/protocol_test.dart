import 'package:flutter_test/flutter_test.dart';
import 'package:rendimiento_grupo5/protocol.dart';
void main(){
  test('9 piloto, 18 aisladas, 90 principales por entorno',(){
    expect(plan(Phase.pilot).length,9);expect(plan(Phase.isolated).length,18);expect(plan(Phase.main).length,90);
    for(final p in Phase.values){final a=plan(p),b=plan(p);expect(a.map((t)=>t.id).toList(),b.map((t)=>t.id).toList());expect(a.map((t)=>t.id).toSet().length,a.length);}
  });
  test('pares alternados, con carga equivalente',(){for(final phase in [Phase.isolated,Phase.main]){final p=plan(phase);for(int i=0;i<p.length;i+=2){final a=p[i],b=p[i+1];expect(a.scenario,b.scenario);expect(a.load,b.load);expect(a.repetition,b.repetition);expect(a.order,1);expect(b.order,2);expect(a.repetition.isOdd?a.variant:b.variant,Variant.v0);}}});
  test('cargas, variantes y cuantil lineal',(){expect(Scenario.transitions.elements(Load.high),60);expect(Scenario.lists.elements(Load.high),1000);expect(Scenario.transforms.elements(Load.high),120);expect(Variant.v2.optimizes(Scenario.lists),true);expect(Variant.v2.optimizes(Scenario.transforms),false);expect(quantile([0,10,20],.95),19);expect(quantile([],0.5),isNull);});
  test('CSV escapa comillas y conserva ausencias',(){expect(csvCell('a,"b"'),'"a,""b"""');expect(csvCell(null),'""');});
}
