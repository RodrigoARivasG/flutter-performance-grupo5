"""Procesamiento descriptivo reproducible. Solo incluye registros validados por el grupo."""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

METRICS = {
    'android': ['fps_engine','build_median_ms','build_p95_ms','raster_median_ms','raster_p95_ms','engine_exceeded_pct','heap_initial_mib','heap_peak_mib','heap_final_mib','rss_initial_mib','rss_peak_mib','rss_final_mib'],
    'web': ['fps_web','web_frame_median_ms','web_frame_p95_ms','web_discarded_pct','web_partial_pct','heap_initial_mib','heap_peak_mib','heap_final_mib','rss_initial_mib','rss_peak_mib','rss_final_mib'],
}
SCENARIOS = ['transitions','lists','transforms']
LABELS = {'transitions':'Transiciones','lists':'Listas','transforms':'Transformaciones'}
LOADS = ['low','medium','high']
TREATMENT = dict(zip(SCENARIOS,['V1','V2','V3']))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('csv', nargs='+', type=Path)
    ap.add_argument('--out', type=Path, default=Path('analisis'))
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    df=pd.concat([pd.read_csv(f,dtype=str,keep_default_na=False,encoding='utf-8-sig') for f in args.csv],ignore_index=True)
    required={'id','attempt','status','phase','platform','scenario','load','version','rep','window_s','trace_file','memory_file','integrated_strategy'}
    if not required.issubset(df.columns): raise SystemExit(f'Columnas faltantes: {required-set(df.columns)}')
    if df.duplicated(['platform','id','attempt']).any(): raise SystemExit('Hay intentos duplicados. Use solo una exportación final por entorno.')
    df['status']=df.status.str.strip().str.lower()
    df.loc[df.status!='valid'].to_csv(args.out/'excluidos_o_pendientes.csv',index=False)
    a=df.loc[df.status=='valid'].copy()
    if a.empty: raise SystemExit('No existen registros marcados valid. Revise las evidencias antes de analizar.')
    if a.duplicated(['platform','phase','scenario','load','version','rep']).any(): raise SystemExit('Hay más de un registro válido para la misma condición/repetición.')
    if (~a.platform.isin(METRICS)).any() or (~a.scenario.isin(SCENARIOS)).any() or (~a.load.isin(LOADS)).any(): raise SystemExit('Plataforma, escenario o carga no reconocidos.')
    a['rep']=pd.to_numeric(a.rep,errors='raise').astype(int)
    for r in a.itertuples():
        versions={'pilot':['V0'],'isolated':['V0',TREATMENT[r.scenario]],'main':['V0','Vopt']}
        if r.phase not in versions or r.version not in versions[r.phase] or r.rep not in range(1,{'pilot':1,'isolated':3,'main':5}[r.phase]+1) or (r.phase=='isolated' and r.load!='high'):
            raise SystemExit(f'Condición fuera de protocolo: {r.id}')
        if not r.trace_file.strip(): raise SystemExit(f'Falta traza de {r.id}; no marque valid sin respaldo.')
    if len(set(a.loc[(a.phase=='main')&(a.version=='Vopt'),'integrated_strategy']))>1: raise SystemExit('Vopt tiene estrategias diferentes: revise congelación del protocolo.')
    numeric=set(sum(METRICS.values(),[]))|{'window_s','web_complete_frames','web_total_frames','web_discarded_frames','web_partial_frames'}
    for k in numeric:
        if k not in a: a[k]=np.nan
        else:
            original=a[k].astype(str).str.strip(); parsed=pd.to_numeric(original,errors='coerce')
            bad=parsed.isna()&~original.str.lower().isin(['','na','n/a','nd','n/d','nan'])
            if bad.any(): raise SystemExit(f'Valor no numérico en {k}. Use punto decimal y blanco para ausencias.')
            a[k]=parsed
        if (a[k]<0).any(): raise SystemExit(f'Valor negativo en {k}')
    if (a.window_s.isna() | (a.window_s<=0)).any(): raise SystemExit('Ventana inválida.')
    # Chrome: derive rates only when counts are available; never use inverse build time.
    w=a.platform=='web'; enough=w&a.web_complete_frames.notna()
    a.loc[enough,'fps_web']=a.loc[enough,'web_complete_frames']/a.loc[enough,'window_s']
    for count,pct in [('web_discarded_frames','web_discarded_pct'),('web_partial_frames','web_partial_pct')]:
        good=w&a[count].notna()&(a.web_total_frames>0)
        a.loc[good,pct]=100*a.loc[good,count]/a.loc[good,'web_total_frames']
    for count in ['web_complete_frames','web_discarded_frames','web_partial_frames']:
        if (a[count]>a.web_total_frames).any(): raise SystemExit(f'{count} supera total de cuadros.')
    for k in ['engine_exceeded_pct','web_discarded_pct','web_partial_pct']:
        if (a[k]>100).any(): raise SystemExit(f'Porcentaje superior al 100 en {k}.')
    coverage=[]; summaries=[]; comparisons=[]; individual=[]
    for phase in ['isolated','main']:
        for platform,metrics in METRICS.items():
            for scenario in SCENARIOS:
                for load in (['high'] if phase=='isolated' else LOADS):
                    expected=3 if phase=='isolated' else 5
                    v='Vopt' if phase=='main' else TREATMENT[scenario]
                    subset=a[(a.phase==phase)&(a.platform==platform)&(a.scenario==scenario)&(a.load==load)]
                    coverage.append(dict(phase=phase,platform=platform,scenario=scenario,load=load,expected_pairs=expected,v0=(subset.version=='V0').sum(),treatment=(subset.version==v).sum()))
                    for metric in metrics:
                        groups={ver:subset[subset.version==ver].set_index('rep')[metric].dropna().sort_index() for ver in ('V0',v)}
                        for ver,s in groups.items():
                            if s.empty: continue
                            summaries.append(dict(phase=phase,platform=platform,scenario=scenario,load=load,version=ver,metric=metric,n=len(s),expected_n=expected,mean=s.mean(),sd=s.std(ddof=1),median=s.median(),minimum=s.min(),maximum=s.max()))
                        pairs=pd.concat([groups['V0'].rename('baseline'),groups[v].rename('treatment')],axis=1).dropna()
                        if pairs.empty: continue
                        diff=pairs.treatment-pairs.baseline
                        favorable=diff if metric.startswith('fps') else -diff
                        pct=100*favorable/pairs.baseline.replace(0,np.nan)
                        for rep, row in pairs.iterrows():
                            individual.append(dict(phase=phase,platform=platform,scenario=scenario,load=load,metric=metric,rep=rep,baseline=row.baseline,treatment=row.treatment,delta=diff.loc[rep],improvement_pct=pct.loc[rep]))
                        comparisons.append(dict(phase=phase,platform=platform,scenario=scenario,load=load,metric=metric,pairs=len(pairs),expected_pairs=expected,baseline_mean=pairs.baseline.mean(),treatment_mean=pairs.treatment.mean(),mean_delta=diff.mean(),mean_improvement_pct=pct.mean(),favorable_pairs=int((favorable>0).sum())))
    pd.DataFrame(coverage).to_csv(args.out/'cobertura_protocolo.csv',index=False)
    pd.DataFrame(summaries).to_csv(args.out/'resumen.csv',index=False)
    pd.DataFrame(comparisons).to_csv(args.out/'comparaciones.csv',index=False)
    paired=pd.DataFrame(individual); paired.to_csv(args.out/'pares.csv',index=False)
    if not paired.empty:
        for platform, metrics in METRICS.items():
            for phase in ['isolated','main']:
                for metric in metrics:
                    sub=paired[(paired.platform==platform)&(paired.phase==phase)&(paired.metric==metric)]
                    if sub.empty: continue
                    fig,axes=plt.subplots(1,3,figsize=(10.5,4.2),sharey=True)
                    for ax,scenario in zip(axes,SCENARIOS):
                        sc=sub[sub.scenario==scenario]; ax.set_title(LABELS[scenario]); ax.grid(axis='y',alpha=.25)
                        ticks=[]; labels=[]
                        for j,load in enumerate(['high'] if phase=='isolated' else LOADS):
                            ss=sc[sc.load==load]; x=j*3
                            for r in ss.itertuples(): ax.plot([x,x+1],[r.baseline,r.treatment],marker='o',alpha=.6)
                            ticks.extend([x,x+1]);labels.extend([load+'\nV0', load+'\n'+('Vopt' if phase=='main' else TREATMENT[scenario])]);
                        ax.set_xticks(ticks,labels,fontsize=7); ax.set_xlabel(f'{len(sc)} pares disponibles')
                    axes[0].set_ylabel(metric); fig.suptitle(f'{platform} · {phase} · {metric} (cada línea = 1 par)');fig.tight_layout();fig.savefig(args.out/f'{platform}_{phase}_{metric}.png',dpi=180);plt.close(fig)
    a.to_csv(args.out/'datos_validados.csv',index=False)
    print(f'Procesados {len(a)} registros validados. Resultados: {args.out}. Revise cobertura y ausencias antes de concluir.')
if __name__=='__main__': main()
